Besides tests for the package `dd`, this directory contains the script
`inspect_cython_signatures.py`, which checks the compliance of a Cython
class to a Python specification (motivated by the unavailability of `ABC`
in Cython).
