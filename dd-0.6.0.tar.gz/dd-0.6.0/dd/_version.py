# This file was generated from setup.py
version = '0.6.0'
